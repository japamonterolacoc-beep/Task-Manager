# Task-Manager
A simple and efficient task manager application that allows users to create, update, organize, and track tasks. It helps users stay productive by managing deadlines, priorities, and progress in one place.
